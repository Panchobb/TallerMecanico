#include "MenuPrincipal.h"

int main() {
    MenuPrincipal();
    return 0;
}
